package com.example.android.projectonlineacc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class Add_Annoucemnt extends AppCompatActivity implements LocationListener {
private ImageView back;
    private Uri image_uri;
    private FirebaseAuth firebaseAuth;//مخصص لتسجيل الدخول عشان اخزن الايميل
    private ProgressDialog progressDialog,progressDialog1;
    private LocationManager locationManager;//مخصص لقوقل ماب
    private ImageView productIconIv;
    //عشان اوصل لعناصر الموجوده داخل add
    private EditText title, price, Description,phone;
    private TextView latitude, longtudie,  adressss1,numberAddID;
    private Button add_announcemnts;



    private String idd="b";
    //permission constants;
    private static final int CAMERA_REQUET_CODE = 200;
    private static final int STORAGE_REQUEST_CODE = 300;
    //image pick constants
    private static final int IMAGE_PICK_GALLARY_CODE = 400;
    private static final int IMAGE_PICK_CAMERA_CODE = 500;
    //location
    private static final int LOCATION_REQUEST_CODE = 100;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private String[] locationPermission;
    //permission arrays
    private String[] cameraPermissions;
    private String[] storagePermission;
    private double rlatitude = 0.0, rlongtudie = 0.0;
    private String radress;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_annoucemnt);
        back=findViewById(R.id.back_to_main);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //هذي عشان نربط بين العناصر يلي عرفنها وبين id
            numberAddID=findViewById(R.id.id_n);
            title = findViewById(R.id.title_add);
            price = findViewById(R.id.price_add);
            Description = findViewById(R.id.description_add);
            latitude = findViewById(R.id.lattude_add);
            longtudie = findViewById(R.id.longtude_add);
            add_announcemnts = findViewById(R.id.Add_acc_buton);
            productIconIv = findViewById(R.id.image_view_announcemnt);

            phone=findViewById(R.id.phone_add);
            adressss1 = findViewById(R.id.adress_add);
            //init permission arrays


        //عمليه برمجة الازرار عند اضافة الاعلان
          getNumberIDAdd();
            add_announcemnts.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //flow:
                    inputData();
                }
            });
            productIconIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showImagePickDialog();
                }
            });



            cameraPermissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            storagePermission = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
            locationPermission = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
            firebaseAuth = FirebaseAuth.getInstance();
            //setup progressbar
            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please wait");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog1 = new ProgressDialog(this);
            progressDialog1.setTitle("Please wait");
            progressDialog1.setCanceledOnTouchOutside(false);
        if (checkLocationPermission()) {
            detectedLocation();



        }

        }

        private void getNumberIDAdd()

        {

            //get all products
            DatabaseReference ref= FirebaseDatabase.getInstance().getReference("AnnouncemntsAll");
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists()) {
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            idd = String.valueOf(ds.getChildrenCount());
                            numberAddID.setText(idd);
                        }
                    }
                    else
                    {
                        numberAddID.setText("0");
                    }




                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }


        private void requstLocationPermission() {
            ActivityCompat.requestPermissions(this, locationPermission, LOCATION_REQUEST_CODE);
        }


        private String productTitle, productDescription, productSalary, productlatitude, productlongtudie,profuctPhone;

    //داله
    //نتأكد ان ما تكون فاضيه لانه مستحيل ارسل بيانات واخزنها وتكون فاضيه
        private void inputData() {
            productTitle = title.getText().toString().trim();
            productDescription = Description.getText().toString().trim();
            productSalary = price.getText().toString().trim();
            productlongtudie = longtudie.getText().toString().trim();
            productlatitude = latitude.getText().toString().trim();
            profuctPhone=phone.getText().toString().trim();

            if (TextUtils.isEmpty(productTitle)) {
                Toast.makeText(this, "Title is required..", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(productDescription)) {
                Toast.makeText(this, "Description is required..", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(productSalary)) {
                Toast.makeText(this, "Price is required..", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(profuctPhone)) {
                Toast.makeText(this, "Phone is required..", Toast.LENGTH_SHORT).show();
                return;
            }

            if (rlatitude == 0.0 || rlongtudie == 0.0) {
                Toast.makeText(this, "plase click Gps button to detectd location", Toast.LENGTH_SHORT).show();
                return;
            }
//اذا كانت مو فاضه نستدعي داله addpro
            addProduct();
        }

        private void addProduct() {
            progressDialog.setMessage("Adding Announcemnts");
            progressDialog.show();

            radress=adressss1.getText().toString();


            String idn=numberAddID.getText().toString();
            int n=Integer.parseInt(idn);
            n=n+1;
            String id=String.valueOf(n);


            String timestamp = "" + System.currentTimeMillis();
//لها شرطين نقدر نظيف اعلان بدون صوره او مع صوره
            if (image_uri == null) {
                //upload with out image
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("Id", id);
                hashMap.put("Title", productTitle);
                hashMap.put("Description", "" + productDescription);
                hashMap.put("Image", "");
                hashMap.put("Price", productSalary);
                hashMap.put("Longtudie", rlongtudie);
                hashMap.put("Latitude", rlatitude);
                hashMap.put("adress", radress);
                hashMap.put("phone", profuctPhone);
                hashMap.put("timestamp", timestamp);
                hashMap.put("uid", firebaseAuth.getUid());
                //set value hashmap
                //  مره وحده فقط وراح يحفظلي artebut كامله في hashmap ومن هاش ماب realtime

                //add to db
                //عرفت  DatabaseReference reference بأسم Users
                //Uid وداخل reference.child بأسم
                // داخلUid وبعدين child باسمAnnouncemnts
                DatabaseReference reference = (FirebaseDatabase.getInstance().getReference("Users"));
                reference.child(firebaseAuth.getUid()).child("Announcemnts").child(id).setValue(hashMap)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                // اذا تمت العمليه بنجاح اظهرلي  Announcmnts added

                                Toast.makeText(Add_Annoucemnt.this, "Announcmnts added ", Toast.LENGTH_SHORT).show();
                                clearData();
                                progressDialog.dismiss();


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
     //ولما تفشل العمليه اظهرلي رساله ولكن من البارد يشن لانه ممكن يكون الظنام معطل او قاعده البيانات محذوفه بكذا يظهرلي السبب الرساله يحصل عليها من داخل الفاير بيس
                            public void onFailure(@NonNull Exception e) {
                                progressDialog.dismiss();
                                Toast.makeText(Add_Annoucemnt.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                // عرفناDatabaseReference reference1 ثاني باسمAnnouncemntsAll بداخله Announcemnts
                DatabaseReference reference1 = (FirebaseDatabase.getInstance().getReference("AnnouncemntsAll"));
                reference1.child("Announcemnts").child(id).setValue(hashMap)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {

                                Toast.makeText(Add_Annoucemnt.this, "Announcmnts added ", Toast.LENGTH_SHORT).show();
                                clearData();
                                finish();
                                progressDialog.dismiss();


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressDialog.dismiss();
                                Toast.makeText(Add_Annoucemnt.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                // يلي فوق كانت بدون صوره
                // والان نسوي كود لما يكون بصوره
            } else
            {
                String filePathAndName = "announcemnts_image/" + "" + id;
                //upload with image
                //عرفتاStorageReference storageReference بعدين سويت putFile باسم image_uri وبكذا تتخزن داخل storage
                StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathAndName);
                (storageReference.putFile(image_uri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            //Adding Announcemnts اذا تم العمليه بنجاح اظهرلي رسالة
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                progressDialog1.setMessage("Adding Announcemnts");
                                progressDialog1.show();
                                Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                                while (!uriTask.isSuccessful()) ;

                                Uri downloadImageUri = uriTask.getResult();
                                if (uriTask.isSuccessful()) {

                                    HashMap<String, Object> hashMap = new HashMap<>();
                                    hashMap.put("Id", "" + id);
                                    hashMap.put("Title", "" + productTitle);
                                    hashMap.put("Description", "" + productDescription);
                                    hashMap.put("Image", "" + downloadImageUri);
                                    hashMap.put("Price", "" + productSalary);

                                    hashMap.put("Longtudie", rlongtudie);
                                    hashMap.put("Latitude", rlatitude);

                                    hashMap.put("adress", radress);
                                    hashMap.put("phone", profuctPhone);
                                    hashMap.put("timestamp", timestamp);
                                    hashMap.put("uid", firebaseAuth.getUid());
                             // بعد ماتمت العمليه بنجاح نعرف hashmap عشان نظيف البيانات تبع الاعلان يلي فيه صوره
                                    // وبعد نظيفه في اليوزر

                                    //add to db
                                    DatabaseReference reference = (FirebaseDatabase.getInstance().getReference("Users"));
                                    reference.child(firebaseAuth.getUid()).child("Announcemnts").child(id).setValue(hashMap)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {

                                                    Toast.makeText(Add_Annoucemnt.this, "Announcmnts added ", Toast.LENGTH_SHORT).show();
                                                    progressDialog1.dismiss();
        // بعدين نستدعي clearData بحالة تم العمليه بنجاح يروح يصفرلي ايه يعني يتحول الا null عشان اتمكن اظيف مره ثانيه
                                                    clearData();
                                                    //           finish();



                                                }
                                            })
                                            // دالهaddOnFailureListener في حال تم عرض شغلي علنيا اظهرلي رسالة
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    progressDialog1.dismiss();
                                                    Toast.makeText(Add_Annoucemnt.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                    DatabaseReference reference1 = (FirebaseDatabase.getInstance().getReference("AnnouncemntsAll"));
                                    reference1.child("Announcemnts").child(id).setValue(hashMap)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    // اذا تم العمليه بنجاح اظهرلي رسالةAnnouncmnts added


                                                    Toast.makeText(Add_Annoucemnt.this, "Announcmnts added ", Toast.LENGTH_SHORT).show();
                                                    progressDialog1.dismiss();
                                                    clearData();
                                                    finish();



                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    progressDialog1.dismiss();
                                                    Toast.makeText(Add_Annoucemnt.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                }
                                            });

                                }
                            }


                        })).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(Add_Annoucemnt.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                    }
                });


            }

        }

        private void clearData() {
            title.setText("");
            Description.setText("");
            price.setText("");
            longtudie.setText("");
            latitude.setText("");
            productIconIv.setImageResource(R.drawable.ic_baseline_add_a_photo_24);
            image_uri = null;

            adressss1.setText("");
            phone.setText("");
        }

        private void showImagePickDialog() {
            String[] options = {"Camera", "Gallery"};
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Pick Image")
                    .setItems(options, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (i == 0) {
                                //camera cliked
                                if (checkCameraPremission()) {
                                    pickFromCamera();
                                } else {
                                    requestCameraPermission();
                                }
                            } else {
                                if (checkStroagePermission()) {
                                    pickFromGallery();
                                } else {
                                    requestStoragePermission();
                                }
                            }
                        }
                    })
                    .show();
        }
// الاستيديو
        private void pickFromGallery() {
            // نعرف Intent ب ACTION_PICK
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            // راح تتخزن في متغير IMAGE_PICK_GALLARY_CODE هذا عشان اخذ الصوره من داخل pickFromGallery
            startActivityForResult(intent, IMAGE_PICK_GALLARY_CODE);
        }

        private void pickFromCamera() {
            ContentValues contentValues = new ContentValues();
            contentValues.put(MediaStore.Images.Media.TITLE, "Temp_Image_Title");
            contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Temp_Image_Description");

            image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            // الكاميرا
            // عشان اخذ الصوره من داخل الكاميرا راح افتح Intent نوعهMediaStore.ACTION_IMAGE_CAPTURE
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
            startActivityForResult(intent, IMAGE_PICK_CAMERA_CODE);
        }
        // هذا عشان يشيك على الاستديو اذا كانت فعاله او لا
        private boolean checkStroagePermission() {
            boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    (PackageManager.PERMISSION_GRANTED);
            return result;
        }
        // اذا لم تكن فعاله يستدعيلي
        private void requestStoragePermission() {
            ActivityCompat.requestPermissions(this, storagePermission, STORAGE_REQUEST_CODE);
        }
        //هذا عشان يفحص الكميره اذا كانت فعاله او لا
        private boolean checkCameraPremission() {
            boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                    (PackageManager.PERMISSION_GRANTED);

            boolean result1 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    (PackageManager.PERMISSION_GRANTED);

            return result && result1;
        }
        //اذا لا يستدعيلي هذي الداله
        private void requestCameraPermission() {
            ActivityCompat.requestPermissions(this, cameraPermissions, STORAGE_REQUEST_CODE);
        }
        //handeled permission


        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            switch (requestCode) {
                // هذي للوكيشن لو شغال
                case LOCATION_REQUEST_CODE: {
                    if (grantResults.length > 0) {
                        boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                        // يستدعي لتحديد الموقع
                        if (locationAccepted) {
                            detectedLocation();

                        } else {
                            Toast.makeText(this, "Location permission is necercry", Toast.LENGTH_SHORT).show();
                        }
                    }
                }break;
                case CAMERA_REQUET_CODE: {
                    if (grantResults.length > 0) {
                        boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                        boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                        if (cameraAccepted && storageAccepted) {
                            pickFromCamera();
                        } else {
                            Toast.makeText(this, "Camera & Storage Permissions are Required,,", Toast.LENGTH_SHORT).show();
                        }
                    }
                }break;
                case STORAGE_REQUEST_CODE: {
                    if (grantResults.length > 0) {
                        boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                        if (storageAccepted) {
                            pickFromCamera();
                        } else {
                            Toast.makeText(this, " Storage Permissions is Required,,", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            if (resultCode == RESULT_OK) {
                if (requestCode == IMAGE_PICK_GALLARY_CODE) {
                    image_uri = data.getData();

                    //set image
                    productIconIv.setImageURI(image_uri);
                } else if (requestCode == IMAGE_PICK_CAMERA_CODE) {
                    productIconIv.setImageURI(image_uri);
                }
            }
            super.onActivityResult(requestCode, resultCode, data);
        }

        @SuppressLint("MissingPermission")
        private void detectedLocation() {
            // هذا لتحديد الموقع وبعده يستدعي داله Find adress
            progressDialog.setMessage("fiend your location");
            progressDialog.show();
            Toast.makeText(this, "please wait ", Toast.LENGTH_LONG).show();
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        }

        @Override
        public void onLocationChanged(@NonNull Location location) {
            rlatitude=location.getLatitude();
            rlongtudie=location.getLongitude();

            //هذي اهي داله يلي استدعينها وظيفتها تاخذAddress وتحطه داخل Text viwe الموجود في صفحه add
            findAddress();
        }

        private void findAddress()
        {
            Geocoder geocoder;
            List<Address> addresses;
            geocoder=new Geocoder(this, Locale.getDefault());

            try {
                addresses=geocoder.getFromLocation(rlatitude,rlongtudie,1);
                String adressss=addresses.get(0).getAddressLine(0);

                String aa= String.valueOf(addresses.get(0).getLongitude());
                String bb= String.valueOf(addresses.get(0).getLatitude());
                //set

                 //يلي هي خط الطول والعرض واخذنها من داله getLongitude وبعد خط adressss ماخوذه من دالةgetAddressLine


                adressss1.setText(adressss);
                longtudie.setText(aa);
                latitude.setText(bb);
                progressDialog.dismiss();




            }
            catch (Exception e)
            {
                Toast.makeText(this,""+e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
        // هذي لفحص الوكيشن
        public boolean checkLocationPermission() {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                // Should we show an explanation?
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_FINE_LOCATION)) {

                    // Show an explanation to the user *asynchronously* -- don't block
                    // this thread waiting for the user's response! After the user
                    // sees the explanation, try again to request the permission.
                    new AlertDialog.Builder(this)
                            .setTitle("allow location permission")
                            .setMessage("allow location permission")
                            .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    //Prompt the user once explanation has been shown
                                    ActivityCompat.requestPermissions(Add_Annoucemnt.this,
                                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                            MY_PERMISSIONS_REQUEST_LOCATION);
                                }
                            })
                            .create()
                            .show();


                } else {
                    // No explanation needed, we can request the permission.
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            MY_PERMISSIONS_REQUEST_LOCATION);
                }
                return false;
            } else {
                return true;
            }
        }
 // هذي دوال ولكنها فاضيه كتبنها عشان استخدمنا لوكيشن مانقر ضروري نسوي ايم بلمنت لهذي الدوال ولو حذفنها راح يطلعلي ايرور ضروري تكون موجوده

        @Override
        public void onLocationChanged(@NonNull List< Location > locations) {

        }

        @Override
        public void onFlushComplete(int requestCode) {

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(@NonNull String provider) {



        }

        @Override
        public void onProviderDisabled(@NonNull String provider) {
            Toast.makeText(this,"Please Turn on location..",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPointerCaptureChanged(boolean hasCapture) {

        }
    }