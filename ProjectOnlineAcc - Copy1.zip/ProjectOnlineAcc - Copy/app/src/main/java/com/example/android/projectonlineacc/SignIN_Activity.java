package com.example.android.projectonlineacc;
// صفحه تسجيل دخول
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignIN_Activity extends AppCompatActivity {
private TextView signUp;
    Button btn;
    TextView signin,signup;
    private ProgressDialog progressDialog;
    private EditText emailTextView, passwordTextView;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
       signUp=findViewById(R.id.or_signUp);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Subscribe.class);
                startActivity(intent);
            }
        });

        btn=findViewById(R.id.signupp);



        emailTextView = findViewById(R.id.Email_log);
        passwordTextView = findViewById(R.id.password_log);
        mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait");
        progressDialog.setCanceledOnTouchOutside(false);



        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

                loginAccount();
            }
        });


    }
    private void loginAccount()
    {

        // show the visibility of progress bar to show loading


        // Take the value of two edit texts in Strings
        String email, password;
        email = emailTextView.getText().toString();
        password = passwordTextView.getText().toString();

        // validations for input email and password
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter email!!",
                    Toast.LENGTH_LONG)
                    .show();

            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter password!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            Toast.makeText(getApplicationContext(),
                    "Please enter correct email address!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (password.length()<=6)
        {
            Toast.makeText(getApplicationContext(),
                    "Password must be atleast 6 characters long..",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
// لو بنسجل الايميل و الباسورد وفرت لنا دالة signInWithEmailAndPassword و address عشان نسجل الايميل و الباسورد
        progressDialog.setMessage("Sign in..");
        progressDialog.show();
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(
                        task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(),
                                        "Login successful!!",
                                        Toast.LENGTH_LONG)
                                        .show();

                                // hide the progress bar
                                progressDialog.dismiss();

                                // if sign-in is successful

                                Intent intent
                                        = new Intent(SignIN_Activity.this,
                                        ListAnnouncemnts.class);
                                startActivity(intent);
                            }

                            else {

                                // sign-in failed
                                Toast.makeText(getApplicationContext(),
                                        "Login failed!!",
                                        Toast.LENGTH_LONG)
                                        .show();

                                // hide the progress bar
                                progressDialog.dismiss();
                            }
                        });


    }
    public static boolean  checkIfEmailVerified(FirebaseUser FirebaseUser)

    {

        if (FirebaseUser != null) {

            return FirebaseUser.isEmailVerified();

        }

        return false;

    }

    @Override
    protected void onStart() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (  checkIfEmailVerified(user)&&user!=null) {
            Intent intent = new Intent(getApplicationContext(),
                    ListAnnouncemnts.class);
            startActivity(intent);
            finish();
        } else {

        }
        super.onStart();
    }


}