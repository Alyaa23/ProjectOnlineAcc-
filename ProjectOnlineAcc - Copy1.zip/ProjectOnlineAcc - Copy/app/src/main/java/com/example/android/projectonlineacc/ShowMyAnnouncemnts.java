package com.example.android.projectonlineacc;
// صفحه عرض الاعلانات
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.android.projectonlineacc.MyAdapter.AdapterProduct;
import com.example.android.projectonlineacc.MyModal.MYModelProduct;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ShowMyAnnouncemnts extends AppCompatActivity {
    RecyclerView productRv;
    // عرفنا المتغيرات وسوينا ربط
    private ArrayList<MYModelProduct> productList;
    private AdapterProduct adapterProduct;
    private ProgressDialog progressDialog33;
    private FirebaseAuth firebaseAuth;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_my_announcemnts);
        productRv=findViewById(R.id.ShoMyAnccRecyclerView);
        imageView=findViewById(R.id.close_add);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog33=new ProgressDialog(this);

        LoadAllProducts();
    }

    private void LoadAllProducts() {
        progressDialog33.setTitle("Please wait");
        progressDialog33.setCanceledOnTouchOutside(false);
        progressDialog33.setMessage("update data");
        progressDialog33.show();
        productList=new ArrayList<>();
        //get all products
        // اول شي نروح على اليوزر بعدين على Uid بعدين على Announcemnts
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
       ref.child(firebaseAuth.getUid()).child("Announcemnts").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // والان تم تحميل كل الاعلانات
                productList.clear();
                for (DataSnapshot ds:snapshot.getChildren()) {
                    MYModelProduct modelProduct = ds.getValue(MYModelProduct.class);
                    productList.add(modelProduct);
                }


 // داله عرض الاعلانات  ShowMyAnnouncemnts
                adapterProduct = new AdapterProduct(ShowMyAnnouncemnts.this, productList);
                productRv.setLayoutManager(new GridLayoutManager(ShowMyAnnouncemnts.this, 2, GridLayoutManager.VERTICAL, false));

                progressDialog33.dismiss();
                productRv.setAdapter(adapterProduct);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}