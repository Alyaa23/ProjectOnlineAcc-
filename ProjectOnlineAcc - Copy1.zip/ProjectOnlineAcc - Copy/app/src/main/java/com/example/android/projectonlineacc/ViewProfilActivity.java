package com.example.android.projectonlineacc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

public class ViewProfilActivity extends AppCompatActivity {
    private FirebaseAuth FirebaseAuth;
    FirebaseDatabase database;
    FirebaseUser user;
    private TextView Location,Age;
    private FirebaseAuth firebaseAuth;
    TextView Name,Mobile,Email,Date;
    ImageView close;
    Button logout,Update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profil);
        Location=findViewById(R.id.location_prof);
        Age=findViewById(R.id.age_prof);
        FirebaseAuth = com.google.firebase.auth.FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        FirebaseApp.initializeApp(this);
        Name=findViewById(R.id.name_prof);
        Mobile=findViewById(R.id.phone_prof);
        Email=findViewById(R.id.email_prof);
Update=findViewById(R.id.update_add);
        logout=findViewById(R.id.logout_prof);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                Intent intent = new Intent(getApplicationContext(),
                        SignIN_Activity.class);
                startActivity(intent);
                finish();
            }
        });

        firebaseAuth=FirebaseAuth.getInstance();

        loadMyInfo();
        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              saveFirebaseData();
            }
        });

    }
    private void loadMyInfo()
    {
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot ds:snapshot.getChildren())
                        {
                            String name=""+ds.child("name").getValue();
                            String phone=""+ds.child("phone").getValue();
                            String email=""+ds.child("email").getValue();
                            String data=""+ds.child("timestamp").getValue();
                            String age=""+ds.child("age").getValue();
                            String location=""+ds.child("location").getValue();

                            // main_name.setText(name);
                            //main_email.setText(email);
                            //show_text_circle.setText(name.substring(0,2));
                            Mobile.setText(phone);
                            Name.setText(name);
                            Email.setText(email);
                            Location.setText(location);
                            Age.setText(age);



                           // Date.setText(getDateTime(Long.parseLong(data)));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
    private String getDateTime(Long time) {
        Calendar calendar = Calendar.getInstance(Locale.ENGLISH);

        calendar.setTimeInMillis(time);

        //dd=day, MM=month, yyyy=year, hh=hour, mm=minute, ss=second.

        String date = DateFormat.format("dd-MM-yyyy hh:mm:ss",calendar).toString();
        return date;
    }
    private void saveFirebaseData() {
        String EMAIL=Email.getText().toString().trim();
        String NAME=Name.getText().toString().trim();
        String PHONE=Mobile.getText().toString().trim();
        String AGE=Age.getText().toString().trim();
        String LOCATION=Location.getText().toString().trim();
        String timestamp = "" + System.currentTimeMillis();
        //setup data to save
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", "" + FirebaseAuth.getUid());
        hashMap.put("email", "" + EMAIL);
        hashMap.put("name", "" + NAME);
        hashMap.put("phone", "" + PHONE);
        hashMap.put("onLine", "true");
        hashMap.put("age", AGE);
        hashMap.put("location", LOCATION);
        hashMap.put("profileImage", "");
        hashMap.put("timestamp", timestamp);
        //save to db
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(FirebaseAuth.getUid()).setValue(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "done", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_SHORT).show();
            }
        });
    }


}