package com.example.android.projectonlineacc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class gogleMap extends AppCompatActivity implements OnMapReadyCallback {
    private Double xx, yy;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gogle_map);
        Intent intent = getIntent();
        Double a = intent.getDoubleExtra("lonx", 0);
// هنا لما نرسل ACTION_DIAL راح يستقبل خط الطول والرض يلي ارسلتهم بعدها راح يستدعيلي id.googlemap سوينا ربط مع xml
        Double b = intent.getDoubleExtra("laty", 0);
        xx = a;
        yy = b;
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.googlemap);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
// داله onMapReady هي يلي تحرك Marker من مكان الاصلي الا الاحداثيات يلي انا سويتها
        LatLng sydney = new LatLng(yy, xx);
        googleMap.addMarker(new MarkerOptions()
                .position(sydney)
                .title("Marker in"+getTitle()));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
