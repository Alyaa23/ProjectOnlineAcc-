package com.example.android.projectonlineacc.MyAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.android.projectonlineacc.MyModal.Db;
import com.example.android.projectonlineacc.MyModal.myFavClassItem;
import com.example.android.projectonlineacc.R;
import com.squareup.picasso.Picasso;

import java.util.List;


public class FavAdapter extends RecyclerView.Adapter<FavAdapter.ViewHolder> {

    private Context context;
    private List<myFavClassItem> favItemList;
    private Db favDB;


    public FavAdapter(Context context, List<myFavClassItem> favItemList) {
        this.context = context;
        this.favItemList = favItemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fav_element_item_shape,
                parent, false);
        favDB = new Db(context);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.favTextView.setText(favItemList.get(position).getItem_title());
       // holder.favImageView.;favItemList.get(position).getImage());
        try {
            Picasso.get()
                    .load(favItemList.get(position).getItem_image())
                    .resize(200,200)
                    .centerCrop()
                    .onlyScaleDown()
                    .placeholder(R.drawable.ic_baseline_phone_android_24)
                    .into(holder.favImageView);

        }


        catch (Exception e) {

        }
    }

    @Override
    public int getItemCount() {
        return favItemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView favTextView;
        Button favBtn;
        ImageView favImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            favTextView = itemView.findViewById(R.id.favTextView);
            favBtn = itemView.findViewById(R.id.favBtn);
            favImageView = itemView.findViewById(R.id.favImageView);


            //remove from fav after click
            favBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final myFavClassItem favItem = favItemList.get(position);

                    favDB.remove_fav(favItem.getKey_id());
                    removeItem(position);


                }

            });
        }

        private void removeItem(int position) {
            favItemList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, favItemList.size());
        }
    }
}
