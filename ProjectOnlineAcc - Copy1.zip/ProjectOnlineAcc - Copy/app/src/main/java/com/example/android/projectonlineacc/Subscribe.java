package com.example.android.projectonlineacc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class Subscribe extends AppCompatActivity implements LocationListener {

    private ImageView back;
    //location
    private static final int LOCATION_REQUEST_CODE = 100;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private String[] locationPermission;
    private double rlatitude = 0.0, rlongtudie = 0.0;
    private LocationManager locationManager;
    //permission constants;
    private static final int CAMERA_REQUET_CODE = 200;
    private static final int STORAGE_REQUEST_CODE = 300;
    //image pick constants
    private static final int IMAGE_PICK_GALLARY_CODE = 400;
    private static final int IMAGE_PICK_CAMERA_CODE = 500;
    //permission arrays
    private String[] cameraPermissions;
    private String[] storagePermission;

    private EditText emailTextView, passwordTextView,name,phone,age;
    private Button Btn;
    private TextView location_city,Sign;
    private FirebaseAuth FirebaseAuth;
    FirebaseDatabase database;
    private ProgressDialog progressDialog;
    FirebaseUser user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscribe);
        FirebaseAuth = com.google.firebase.auth.FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        FirebaseApp.initializeApp(this);
        back = findViewById(R.id.back_to_sign_in);



        progressDialog = new ProgressDialog(this);
       // Sign = findViewById(R.id.welcomeback);
        progressDialog.setTitle("Please wait");
        progressDialog.setCanceledOnTouchOutside(false);
        // initialising all views through id defined above
        emailTextView = findViewById(R.id.email_sub);
        passwordTextView = findViewById(R.id.password_sub);
        name = findViewById(R.id.name_sub);
        phone = findViewById(R.id.phone_sub);
        Btn = findViewById(R.id.login);
        age = findViewById(R.id.age);
        location_city = findViewById(R.id.location_sub);

        cameraPermissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        storagePermission = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
        locationPermission = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};

        location_city.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkLocationPermission()) {
                    detectedLocation();


                } else {

                }
            }
        });

        if (checkLocationPermission()) {
            detectedLocation();


        } else {

        }
        // Set on Click Listener on Registration button
        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputData();

            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SignIN_Activity.class);
                startActivity(intent);
            }
        });
    }

    private String NAME, EMAIL, PASSWORD, PHONE, AGE, LOCATION;

    private void inputData() {
        //input data
        NAME = name.getText().toString().trim();
        PHONE = phone.getText().toString().trim();
        EMAIL = emailTextView.getText().toString().trim();
        PASSWORD = passwordTextView.getText().toString();
        AGE = age.getText().toString().trim().toString();
        LOCATION = location_city.getText().toString();
        //validate data
        // Validations for input email and password
        if (TextUtils.isEmpty(EMAIL)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter email!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(PASSWORD)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter password!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(PHONE)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter phone number!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(NAME)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter your name!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(AGE)) {
            Toast.makeText(getApplicationContext(),
                    "Please enter your AGE!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(EMAIL).matches()) {
            Toast.makeText(getApplicationContext(),
                    "Please enter correct email address!!",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (PASSWORD.length() <= 6) {
            Toast.makeText(getApplicationContext(),
                    "Password must be atleast 6 characters long..",
                    Toast.LENGTH_LONG)
                    .show();
            return;
        }
        registerNewUser();

    }

    private void requstLocationPermission() {
        ActivityCompat.requestPermissions(this, locationPermission, LOCATION_REQUEST_CODE);
    }

    private void registerNewUser() {

        // show the visibility of progress bar to show loading
        progressDialog.setMessage("Sign up..");
        progressDialog.show();

// عشان نسجل حساب جديد
        // create new user or register new user
        FirebaseAuth
                .createUserWithEmailAndPassword(EMAIL, PASSWORD)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {


                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            // send verification
                            user = FirebaseAuth.getCurrentUser();
                            user.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(
                                            getApplicationContext(),
                                            "Verification email has sent to your email".toUpperCase(Locale.ROOT),
                                            Toast.LENGTH_LONG)
                                            .show();
                                    saveFirebaseData();
                                    Intent aa = new Intent(getApplicationContext(), SignIN_Activity.class);
                                    startActivity(aa);
                                    finish();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(
                                            getApplicationContext(),
                                            "field, Verification email has not sent to your email",
                                            Toast.LENGTH_LONG)
                                            .show();
                                }
                            });

                        } else {
                            Toast.makeText(
                                    getApplicationContext(),
                                    task.getException().toString(),
                                    Toast.LENGTH_LONG)
                                    .show();

                            // hide the progress bar
                            progressDialog.dismiss();
                        }
                    }
                });
    }

    private void saveFirebaseData() {
        String timestamp = "" + System.currentTimeMillis();
        //setup data to save
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", "" + FirebaseAuth.getUid());
        hashMap.put("email", "" + EMAIL);
        hashMap.put("name", "" + NAME);
        hashMap.put("phone", "" + PHONE);
        hashMap.put("onLine", "true");
        hashMap.put("age", AGE);
        hashMap.put("location", LOCATION);
        hashMap.put("profileImage", "");
        hashMap.put("timestamp", timestamp);
        //save to db
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(FirebaseAuth.getUid()).setValue(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "done", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void pickFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_GALLARY_CODE);
    }



    private boolean checkStroagePermission() {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result;
    }

    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this, storagePermission, STORAGE_REQUEST_CODE);
    }

    private boolean checkCameraPremission() {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                (PackageManager.PERMISSION_GRANTED);

        boolean result1 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);

        return result && result1;
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, cameraPermissions, STORAGE_REQUEST_CODE);
    }
    //handeled permission


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (locationAccepted) {

                        detectedLocation();
                    } else {
                        Toast.makeText(this, "Location permission is necercry", Toast.LENGTH_SHORT).show();
                    }
                }
            }break;
            case CAMERA_REQUET_CODE: {
                if (grantResults.length > 0) {
                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (cameraAccepted && storageAccepted) {

                    } else {
                        Toast.makeText(this, "Camera & Storage Permissions are Required,,", Toast.LENGTH_SHORT).show();
                    }
                }
            }break;
            case STORAGE_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted) {

                    } else {
                        Toast.makeText(this, " Storage Permissions is Required,,", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK) {

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @SuppressLint("MissingPermission")
    private void detectedLocation() {
        progressDialog.setMessage("fiend your location");
        progressDialog.show();
        Toast.makeText(this, "please wait ", Toast.LENGTH_LONG).show();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        rlatitude=location.getLatitude();
        rlongtudie=location.getLongitude();

        findAddress();
    }

    private void findAddress()
    {
        Geocoder geocoder;
        List<Address> addresses;
        geocoder=new Geocoder(this, Locale.getDefault());

        try {
            addresses=geocoder.getFromLocation(rlatitude,rlongtudie,1);
            String adressss=addresses.get(0).getAddressLine(0);

            String aa= String.valueOf(addresses.get(0).getLongitude());
            String bb= String.valueOf(addresses.get(0).getLatitude());
            //set

            location_city.setText(adressss);

            progressDialog.dismiss();




        }
        catch (Exception e)
        {
            Toast.makeText(this,""+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("allow location permission")
                        .setMessage("allow location permission")
                        .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(Subscribe.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }


    @Override
    public void onLocationChanged(@NonNull List< Location > locations) {

    }

    @Override
    public void onFlushComplete(int requestCode) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {



    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        Toast.makeText(this,"Please Turn on location..",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}