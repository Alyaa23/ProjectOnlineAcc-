package com.example.android.projectonlineacc.MyModal;
// هذا يخص البيانات مع الاعلان
public class MYModelProduct {
    private String Description,Id,Image,Price,Title,adress,city,country,state,timestamp,phone,uid;
         Double Latitude,Longtudie;
         String key_id;
     String favStatus;
     int imageResourse;


    public MYModelProduct() {
    }
// تمهيد للبيانات
    public MYModelProduct(String id, String title, String description, String image, String price,
                          Double longtudie, Double latitude, String country, String phone,
                          String city, String state, String adress, String timestamp, String uid
    , String favStatus, int imageResourse) {
        Id = id;
        Title = title;
        Description = description;
        Image = image;
        Price = price;
        Longtudie = longtudie;
        Latitude = latitude;
        this.country = country;
        this.city = city;
        this.state = state;
        this.adress = adress;
        this.timestamp = timestamp;
        this.uid = uid;
        this.favStatus=favStatus;
        this.key_id=key_id;
        this.imageResourse=imageResourse;

    }
// داله get و set لكل متغير من المتغيرات
    public int getImageResourse() {
        return imageResourse;
    }

    public void setImageResourse(int imageResourse) {
        this.imageResourse = imageResourse;
    }


    public String getFavStatus() {
        return favStatus;
    }

    public void setFavStatus(String favStatus) {
        this.favStatus = favStatus;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public Double getLongtudie() {
        return Longtudie;
    }

    public void setLongtudie(Double longtudie) {
        Longtudie = longtudie;
    }

    public Double getLatitude() {
        return Latitude;
    }

    public void setLatitude(Double latitude) {
        Latitude = latitude;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
