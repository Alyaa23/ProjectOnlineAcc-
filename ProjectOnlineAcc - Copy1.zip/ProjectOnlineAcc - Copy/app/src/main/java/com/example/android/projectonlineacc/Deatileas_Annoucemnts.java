package com.example.android.projectonlineacc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Deatileas_Annoucemnts extends AppCompatActivity {
    // عرفنا المتغيرات تخص TextView الى اخره
    private TextView textView11_title,textView12_price,textView13_des,textView15_adress;
    private ImageView imageView7,back;
    private Button button2_call,location_button;
    private String phone_call;
    private double x;
    private double y;
    int pooos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deatileas_annoucemnts);
        // هذا الربط عن طريق داله findViewById
back=findViewById(R.id.back_list);
        button2_call=findViewById(R.id.call_det);
        textView11_title=findViewById(R.id.title_det);
        textView12_price=findViewById(R.id.price_det);
        textView13_des=findViewById(R.id.deatiles_det);
        textView15_adress=findViewById(R.id.location_det);
        location_button=findViewById(R.id.open_location_det);
        imageView7=findViewById(R.id.imageView7);
back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        finish();
    }
});

        Intent intent = getIntent();
        // تستقبل البيانات الاعلان من داخل صفحة الارئسيه
        //get the attached extras from the intent
//we should use the same key as we used to attach the data.
        String TITLE = intent.getStringExtra("title");
        String PRICE=intent.getStringExtra("price");
        String DES=intent.getStringExtra("des");
        String image=intent.getStringExtra("icon");
        String Country=intent.getStringExtra("cou");
        String city=intent.getStringExtra("city");
        String adress=intent.getStringExtra("adress");
        String phone=intent.getStringExtra("phone");
        double xx = intent.getDoubleExtra("x", 0);


        double yy = intent.getDoubleExtra("y", 0);
        int pos=intent.getIntExtra("pos",0);
        x=Double.valueOf(xx);
        y=Double.valueOf(yy);
        pooos=Integer.valueOf(pos);
        phone_call=phone;
        //عمليه ارسال او عمليه ضبط القيم بداخل textView
        textView11_title.setText(TITLE);
        textView12_price.setText(PRICE+" RS");
        textView13_des.setText(DES);
        //textView7_country.setText(Country);
      textView15_adress.setText(adress);
        //star.setText(Country+" "+city);



        // هذي اهي المكتبه يلي استخدمنها Picasso يتم اظهار القيم في صفحه ثانيه
        // هي المكتبه تستخدم لتحميل الصوره من داخل الاستورج واظهارها داخل الميفتيتي
        // اخاص بصوره هو url load(image)
        //resize عمليه انه يسوي الحجم حق الصوره
        // centerCrop() وonlyScaleDown() عباره عن دالتين مسؤوله عن حجم الصوره
        //placeholder في حال لا يحتوي على صوره يظهر الصفحه فاضيه
        // نظهر الصوره في into
        try {
            Picasso.get()
                    .load(image)
                    .resize(200,200)
                    .centerCrop()
                    .onlyScaleDown()
                    .placeholder(R.drawable.ic_baseline_phone_android_24)
                    .into(imageView7);

        }

// في حال لو ظغطنا على داله Exception راح يدخل على gogleMap.class بحيث يكون خط الطول والعرض
        catch (Exception e) {

        }
        location_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getApplicationContext(), gogleMap.class);
                intent.putExtra("lonx",xx);
                intent.putExtra("laty",yy);
                startActivity(intent);
            }
        });
// في حال ضغط على زر call now راح يفتح ACTION_DIAL ويرسله الرقم  بعدين يسوي startActivity
        button2_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+phone_call));
                startActivity(intent);
            }
        });




    }


}
