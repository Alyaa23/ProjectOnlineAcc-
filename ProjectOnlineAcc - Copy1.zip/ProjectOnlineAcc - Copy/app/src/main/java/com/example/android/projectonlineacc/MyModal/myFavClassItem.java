package com.example.android.projectonlineacc.MyModal;
// كلاس FAVORITE
public class myFavClassItem {
// عرفنا المتغيرات فقط عشان لانكررها في الكلاسات الاخرا
    private String item_title;
    private String key_id;
    private String item_image;
// سوية ClassItem فاضي لانه ضروري يكون موجود لانه لو كان غير موجود راح يتوقف التطبيق من شروط اي كلاس نسويه يكون هذي الداله فاضيه
    public myFavClassItem() {
    }
// هذا myFavClassItem يسوي تمهيد للبيانات عشان نكون نعرف متغير ونرسله للبيانات
    public myFavClassItem(String item_title, String key_id, String item_image) {
        this.item_title = item_title;
        this.key_id = key_id;
        this.item_image = item_image;
    }
//دالةget و set بكل متغير من المتغيرات get عشان احصل على قيمه set عشان اسوي ضبط للقيمه
    public String getItem_title() {
        return item_title;
    }

    public void setItem_title(String item_title) {
        this.item_title = item_title;
    }

    public String getKey_id() {
        return key_id;
    }

    public void setKey_id(String key_id) {
        this.key_id = key_id;
    }

    public String getItem_image() {
        return item_image;
    }

    public void setItem_image(String item_image) {
        this.item_image = item_image;
    }
}
