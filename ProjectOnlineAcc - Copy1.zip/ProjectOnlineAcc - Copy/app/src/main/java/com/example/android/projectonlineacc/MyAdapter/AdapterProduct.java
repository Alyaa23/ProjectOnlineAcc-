package com.example.android.projectonlineacc.MyAdapter;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.android.projectonlineacc.Deatileas_Annoucemnts;
import com.example.android.projectonlineacc.MyModal.Db;
import com.example.android.projectonlineacc.MyModal.MYModelProduct;
import com.example.android.projectonlineacc.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
// يرث RecyclerView
public class AdapterProduct extends RecyclerView.Adapter<AdapterProduct.HolderProduct> implements Filterable {
    // عرفنا ArrayList للاعلان
    public ArrayList<MYModelProduct> productList;
    public ArrayList<MYModelProduct> filterList;
    // ArrayList بعد للفلتر
    private filterProduct filter;
    private Context context;

    private Db favDB;


// عندنا AdapterProduct
    public AdapterProduct(Context context, ArrayList<MYModelProduct> productList) {
        this.context = context;
        this.productList = productList;
        this.filterList=productList;
    }

    @NonNull
    @Override

    public HolderProduct onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        favDB = new Db(context);
        //create table on first
        // عرفنا متغير first
// عرفنا ايضاSharedPreferences سبب من تعريفنا عشان نتخبر اذا كان المستخدم اول مره يسجل في التطبيق يذهب الا createTableOnFirstStart الخاص بي SQL
// اذا ان اول مره اسجل في التطبيق يتحول حالته من ترو الا فولس
 // اما اذا كان فولس لا يستدعي الداله هذي createTableOnFirstStart
        SharedPreferences prefs = context.getSharedPreferences("prefs", Context.MODE_PRIVATE);
        boolean firstStart = prefs.getBoolean("firstStart", true);
        if (firstStart) {
            createTableOnFirstStart();

        }

        View view= LayoutInflater.from(context).inflate(R.layout.annoucemnts_item_shape,parent,false);
        return new HolderProduct(view);
    }


    @Override
    public void onBindViewHolder(@NonNull HolderProduct holder, int position) {
//هذي كلها تبع الاعلان
       final MYModelProduct modelProduct=productList.get(position);
        readCursorData(modelProduct, holder);
        //get data
        String id=modelProduct.getId();
        String uid=modelProduct.getUid();
        String icon=modelProduct.getImage();
        String title=modelProduct.getTitle();
       String price=modelProduct.getPrice();

        Double lon=modelProduct.getLongtudie();
        Double lan=modelProduct.getLatitude();
        String Description=modelProduct.getDescription();
        String city=modelProduct.getCity();
        String state=modelProduct.getState();
        String adress=modelProduct.getAdress();
        String countery=modelProduct.getCountry();
        String timestamp=modelProduct.getTimestamp();
        String phone=modelProduct.getPhone();
        modelProduct.setFavStatus("0");
        //set data

        holder.title.setText(title);
        holder.price.setText(price);
        //image
        try {
            Picasso.get()
                    .load(icon)
                    .resize(200,200)
                    .centerCrop()
                    .onlyScaleDown()
                    .into(holder.productIconIv, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError(Exception e) {

                        }
                    });


        }


        catch (Exception e) {
            holder.productIconIv.setImageResource(R.drawable.common_full_open_on_phone);


        }

        {
            FirebaseAuth firebaseAuth=FirebaseAuth.getInstance();

            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    int postion = holder.getAdapterPosition();
                    postion++;

                    DatabaseReference reff = FirebaseDatabase.getInstance().getReference("AnnouncemntsAll");

                    reff.child("Announcemnts").child(modelProduct.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot appleSnapshot : snapshot.getChildren()) {

                                appleSnapshot.getRef().removeValue();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }

                    });
                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");

                    ref.child(firebaseAuth.getUid()).child("Announcemnts").child(modelProduct.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot appleSnapshot : snapshot.getChildren()) {

                                appleSnapshot.getRef().removeValue();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }

                    });


                        return false;
            }

            });




            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(holder.itemView.getContext(), Deatileas_Annoucemnts.class);
                    intent.putExtra("title",title);
                    intent.putExtra("price",price);
                    intent.putExtra("des",Description);
                    intent.putExtra("icon",icon);
                    intent.putExtra("cou",countery);
                    intent.putExtra("city",city);
                    intent.putExtra("adress",adress);
                    intent.putExtra("phone",phone);
                    intent.putExtra("x",lon);
                    intent.putExtra("y",lan);
                    intent.putExtra("pos",holder.getAdapterPosition());
                    holder.itemView.getContext().startActivity(intent);
                }

            });


        }
        //readCursorData(modelProduct, holder);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    @Override
    public Filter getFilter() {
        if(filter==null)
        {
            filter=new filterProduct(this,filterList);
        }
        return filter;
    }

    class HolderProduct extends RecyclerView.ViewHolder{
        private ImageView productIconIv;
        private TextView  title,price;
        private ImageView favBtn;


        public HolderProduct(@NonNull View itemView) {
            super(itemView);
            productIconIv=itemView.findViewById(R.id.image_rec);
            title=itemView.findViewById(R.id.title_rec);
            price=itemView.findViewById(R.id.price_ric);
            favBtn = itemView.findViewById(R.id.like_rec);


favBtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
Toast.makeText(context,"dsg",Toast.LENGTH_SHORT).show();
        int position = getAdapterPosition();
        MYModelProduct coffeeItem = productList.get(position);

        if (coffeeItem.getFavStatus().equals("0")) {

            coffeeItem.setFavStatus("1");
            favDB.insertIntoTheDatabase(coffeeItem.getTitle(), coffeeItem.getImage(),
                    coffeeItem.getId(), coffeeItem.getFavStatus());
            favBtn.setBackgroundResource(R.drawable.favorite_like);
            favBtn.setSelected(true);

        } else {
            coffeeItem.setFavStatus("0");
            favDB.remove_fav(coffeeItem.getId());
            favBtn.setBackgroundResource(R.drawable.favorite_unlike);
            favBtn.setSelected(false);
        }
    }
});

        }
    }

    private void createTableOnFirstStart() {


        SharedPreferences prefs = context.getSharedPreferences("prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("firstStart", false);
        editor.apply();
    }
    private void readCursorData(MYModelProduct coffeeItem, HolderProduct viewHolder) {
        Cursor cursor = favDB.read_all_data(coffeeItem.getId());
        SQLiteDatabase db = favDB.getReadableDatabase();
        try {
            while (cursor.moveToNext()) {

             String item_fav_status = cursor.getString(cursor.getColumnIndex(favDB.FAVORITE_STATUS));
                coffeeItem.setFavStatus(item_fav_status);

                //check fav status
                if (item_fav_status != null && item_fav_status.equals("1")) {
                    viewHolder.favBtn.setBackgroundResource(R.drawable.favorite_like);
                } else if (item_fav_status != null && item_fav_status.equals("0")) {
                    viewHolder.favBtn.setBackgroundResource(R.drawable.favorite_unlike);
                }
            }
        }catch (Exception e)
        {
            Toast.makeText(context,e.getMessage().toString(),Toast.LENGTH_LONG).show();
        }
        finally {
            if (cursor != null && cursor.isClosed())
                cursor.close();
            db.close();
        }

    }

}
