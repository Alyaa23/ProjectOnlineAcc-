package com.example.android.projectonlineacc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.android.projectonlineacc.MyAdapter.AdapterProduct;
import com.example.android.projectonlineacc.MyModal.MYModelProduct;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ListAnnouncemnts extends AppCompatActivity {
    private ImageView add,profil;
    private FloatingActionButton fav;
    private ImageView logout_main;
    TextView nameOfUser;
    private FirebaseAuth firebaseAuth;
    private EditText searchProductEt;
    RecyclerView productRv;
    private ImageView ancc_list;
    private ArrayList<MYModelProduct> productList;
    private AdapterProduct adapterProduct;
    private ProgressDialog progressDialog33;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_announcemnts_layout);
        add=findViewById(R.id.add_ancce);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),
                        Add_Annoucemnt.class);
                startActivity(intent);
            }
        });
        fav=findViewById(R.id.favorite);
        profil=findViewById(R.id.Profil_main);
        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),
                        ViewFavorite.class);
                startActivity(intent);
            }
        });
        profil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),
                        ViewProfilActivity.class);
                startActivity(intent);
            }
        });


        nameOfUser=findViewById(R.id.name_main);
        fav=findViewById(R.id.favorite);
        logout_main=findViewById(R.id.logout_main);
        ancc_list=findViewById(R.id.ancc_list);
        ancc_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),
                        ShowMyAnnouncemnts.class);
                startActivity(intent);
            }
        });
        // searchProductEt=findViewById(R.id.searchView);
        productRv=findViewById(R.id.product_recycler);
        firebaseAuth= FirebaseAuth.getInstance();
        searchProductEt=findViewById(R.id.Search_editText);
        progressDialog33=new ProgressDialog(this);
        checkUser();
        LoadAllProducts();






        searchProductEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                try {


                    adapterProduct.getFilter().filter(charSequence);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        logout_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                firebaseAuth.signOut();
                checkUser();
            }
        });
    }

    private void LoadAllProducts() {
        progressDialog33.setTitle("Please wait");
        progressDialog33.setCanceledOnTouchOutside(false);
        progressDialog33.setMessage("update data");
        progressDialog33.show();
        productList=new ArrayList<>();
        //get all products
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("AnnouncemntsAll");
        ref.child("Announcemnts").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                productList.clear();
                for (DataSnapshot ds:snapshot.getChildren()) {
                    MYModelProduct modelProduct = ds.getValue(MYModelProduct.class);
                    productList.add(modelProduct);
                }



                adapterProduct = new AdapterProduct(ListAnnouncemnts.this, productList);
                productRv.setLayoutManager(new GridLayoutManager(ListAnnouncemnts.this, 2, GridLayoutManager.VERTICAL, false));

                progressDialog33.dismiss();
                productRv.setAdapter(adapterProduct);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void checkUser() {
        FirebaseUser user =firebaseAuth.getCurrentUser();
        if(user == null)
        {
            startActivity(new Intent(ListAnnouncemnts.this,WelcomeActivity.class));
            finish();
        }
        else
        {
            loadMyInfo();
        }
    }

    private void loadMyInfo()
    {
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot ds:snapshot.getChildren())
                        {
                            String name=""+ds.child("name").getValue();
                            nameOfUser.setText("HI "+name);
                            //   nameOfUser.setText(name.substring(0,2));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }



}
