package com.example.android.projectonlineacc.MyAdapter;

// هذي الصفحه مسؤوله عن البحث
import android.widget.Filter;


import com.example.android.projectonlineacc.MyModal.MYModelProduct;

import java.util.ArrayList;

public class filterProduct extends Filter {
    private AdapterProduct adapter;
    private ArrayList<MYModelProduct> filterList;



    public filterProduct(AdapterProduct adapter, ArrayList<MYModelProduct> filterList) {
        this.adapter=adapter;
        this.filterList = filterList;
    }

    @Override
    protected FilterResults performFiltering(CharSequence charSequence) {
        FilterResults results=new FilterResults();
        //validate
        if(charSequence !=null && charSequence.length()>0)
        {
            //search

            //change to upper case
            charSequence=charSequence.toString().toUpperCase();
            //store our filter
            ArrayList<MYModelProduct> filterModels=new ArrayList<>();
            for (int i=0;i<filterList.size();i++)
            {
                if(filterList.get(i).getTitle().toUpperCase().contains(charSequence)){
                    filterModels.add(filterList.get(i));

                }
            }
            results.count=filterModels.size();
            results.values=filterModels;
        }
        else
        {
            results.count=filterList.size();
            results.values=filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence charSequence, FilterResults filterResults)
    {
       adapter.productList=(ArrayList<MYModelProduct>)filterResults.values;
       //refresh
          adapter.notifyDataSetChanged();
    }
}
